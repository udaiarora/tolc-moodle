To run the application, install Moodle.
Then clone the application found onto the moodle folder replacing the exsting files. The URL of the Github which will be used for cloning is specified in the file Runable Application.txt
After the application is cloned, there are some database changes to be made. These changes can be found in the file DBInstructions.txt
There are no known bugs. Some aspects of the features are incomplete. Those aspects are specified in DescriptionofFeaturesImplementedandToDos.docx